<?php
/**
 * @package g2builderdfields
 */

namespace Inc\Base;

use Inc\Base\BaseController;

class customAdminColumnscommunities extends BaseController{



}
